//
//  Coke.h
//  Pods
//
//  Created by Times Internet Limited on 5/11/16.
//  Last Updated on 19/06/2018
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>

#define SAFE_STRING(obj) ((obj != nil && obj.length > 0 && ![obj isKindOfClass:[NSNull class]]) ? obj : @"")
#define COKE_SDK_VERSION   @"v2.1.8"


typedef NS_ENUM(NSUInteger, SubscriptionType) {
    SubscriptionTypeMonthly,
    SubscriptionTypeQuartly,
    SubscriptionTypeYearly
};

@interface Coke : NSObject


/**
 *  Set the app code, without app code code sdk will not enabled
 *
 *  @param aAppCode App code.
 *
 */
+ (void)setAppCode:(NSString *)aAppCode;

/**
 *  Get the app code
 *
 *  @return appCode
 */
+ (NSString*)getAppCode;

/**
 *  Start Coke SDK. Note, this will only work when App Code hase been set using setAppCode function. If app Code has not been set, Coke SDK will throw an exception.
 */
+ (void)startWithOptOut:(BOOL)aValue;

/**
 *  Get the UID. This UID is generated from Coke Server. One can only get this UID once the device has been refgistered.
 *
 *  @return Coke UID
 */
+ (NSString*)getCokeUID;

/**
 *  Check if Device has been registered with Coke Server.
 *
 *  @return YES or NO
 */
+ (BOOL)isRegistered;

/**
 *  Set UA (Urban Airship) channle ID.
 *
 *  @param aUAChannelId Channel ID provided by UA
 */
+ (void)setUAChannelId:(NSString *)aUAChannelId;

/**
 *  Set Mobile Number.
 *
 *  @param mobileNumber Value can be User's Mobile Number
 */
+ (void)setMobileNumber:(NSString *)mobileNumber;

/**
 *  Set the Application Rating.
 *
 *  @param appRating Application Rating.
 *
 */
+ (void)setAppRating:(NSString *)appRating;

/**
 *  Set the EmailId of user
 *
 *  @param emailid EmailID.
 *
 */
+ (void)setEmailId:(NSString *)emailid;


/**
 *  Set the PushToken of device. This push token is device push Token provided by apple
 *
 *  @param pushToken DeviceToken.
 *
 */
+ (void)setPushToken:(NSString *)pushToken;


/**
 *  Set the userId of user
 *
 *  @param aUserId Id to identify user like SSO ID
 *
 */
+ (void)setUserId:(NSString *)aUserId;

/**
 *  Set the users current location.
 *
 *  @param location User Location.
 *
 */
+ (void)setLocation:(CLLocation*)location;

/**
 *  Set the users fcmid.
 *
 *  @param aFcmId User fcmid.
 *
 */
+ (void)setFcmid:(NSString*)aFcmId;


/**
 *  Set the users gcmid.
 *
 *  @param aGcmId User gcmid.
 *
 */
+ (void)setGcmid:(NSString*)aGcmId;



/**
 *  Set the users sunsign.
 *
 *  @param aSunsign User sunsign.
 *
 */
+ (void)setSunsign:(NSString *)aSunsign;


/**
 *  Set the time interval between data to be sent to server.
 *
 *  @param timeInterval Time Interval. Default is set to 30 seconds
 *
 */
+ (void)setDispatchTimeInterval:(NSInteger )timeInterval;


/**
 *  Set setting snapshot
 *
 *  @param aSettingInfoList Set SettingInfoList
 *  [{"name":"a","value":"b"},{"name":"x","value":"y"}]
 */

+ (void)setSettingSnapshotList:(NSArray *)aSettingInfoList;

/**
 *  Set setting for device
 *
 *  @param aNewValue Set NewValue
 *  @param aOldValue Set OewValue
 *  @param aKey   Set key
 */
+ (void)setDeviceSettingNewValue:(NSString*)aNewValue oldValue:(NSString*)aOldValue forKey:(NSString*)aKey;

/**
 *  Set User Attributes
 *
 *  @param aValue Set value
 *  @param aKey   Set key
 */

+ (void)setUserAttributeValue:(NSString*)aValue forKey:(NSString*)aKey;

/**
 *  Set Setting value for a particular key
 *
 *  @param aKey key
 *
 *  @return setting value
 */
+ (NSString*)getSettingValueForKey:(NSString*)aKey;

/**
 *  Get Setting Dictionary
 *
 */

+ (NSDictionary*)getSettingDictionary;

/**
 *  Set Language list
 *
 *  @param aLanguageArray language array
 */
+ (void)setLanguageList:(NSArray*)aLanguageArray;

/**
 *  Get Language list
 *
 */
+ (NSArray*)getLanguageList;

/**
 *  Set Channel list
 */

+ (void)setChannelList:(NSArray*)aChannelListArray;

/**
 *
 *  Get Language list
 */

+ (NSArray*)getChannelList;

/**
 *  Set Paid Status
 *
 *  @param aPaid paid value can be true/false
 */
+ (void)setPaidStatus:(BOOL)aPaid;

/**
 *  Set Subscription Status
 *
 * @param aSubscriptionType Value can be SubscriptionTypeMonthly, SubscriptionTypeQuartly, SubscriptionTypeYearly
 */
+ (void)setSubscriptionType:(SubscriptionType)aSubscriptionType;

+ (NSDictionary*)getRegisrationData;

/**x
 *  Send Start Event to SDK
 *  @param aCategory   Set category name
 *  @param aEventName  Possible values (read,notification_delivered,notification_open,video/play,video/pause,install,publication_changed,share/channel,settings_changed,bookmarked,notification_share,
 notification_save,comment,session_start,session_end)
 *  @param aScreenName Set current screen name
 *  @param aFeedURL    Set feed url. Feed URL will be set to “WebView” for web view pages
 *  @param aArticleURL Set article url
 *  @param aClickedAd  Set clickes Ad
 */

+ (NSString *)startEventWithCategory:(NSString*)aCategory
                           eventName:(NSString*)aEventName
                          screenName:(NSString*)aScreenName
                             feedURL:(NSString*)aFeedURL
                          articleURL:(NSString*)aArticleURL
                           clickedAd:(NSString*)aClickedAd;


/**
 *  Send End Event to SDK with Same Event name and Event ID which is provided by SDK
 *  @param aEventName  Possible values (read,notification_delivered,notification_open,video/play,video/pause,install,publication_changed,share/channel,settings_changed,bookmarked,notification_share,
 notification_save,comment,session_start,session_end)
 *  @param eventId  Set eventId
 */
+ (void)endEventWithEventName:(NSString *)aEventName andEventId:(NSString *)eventId;


/**x
 *  Send Event to SDK
 *  @param aCategory   Set category name
 *  @param aEventName  Possible values (read,notification_delivered,notification_open,video/play,video/pause,install,publication_changed,share/channel,settings_changed,bookmarked,notification_share,
 notification_save,comment,session_start,session_end)
 *  @param aScreenName Set current screen name
 *  @param aFeedURL    Set feed url. Feed URL will be set to “WebView” for web view pages
 *  @param aArticleURL Set article url
 *  @param aClickedAd  Set clickes Ad
 *  @param timeSpent   Set timeSpent
 */

+ (void)sendEventWithCategory:(NSString*)aCategory
                    eventName:(NSString*)aEventName
                   screenName:(NSString*)aScreenName
                      feedURL:(NSString*)aFeedURL
                   articleURL:(NSString*)aArticleURL
                    clickedAd:(NSString*)aClickedAd
                     interval:(NSNumber *)timeSpent;


+ (void)setCokeLogEnabled:(BOOL)aValue;

+ (void)setCokeOptOut:(BOOL)aValue;
+ (void)clearCokeRegistrationData;
+ (BOOL)cokeLogEnabled;
+ (NSString *)getDataDownloadAndDeleteUrl;
+ (NSString *)getDataDownloadAndDeleteIdentifier;
+ (NSString*)getDataDownloadAndDeleteIdentifierForCokeAppCode:(NSString*)aAppCode;


@end
