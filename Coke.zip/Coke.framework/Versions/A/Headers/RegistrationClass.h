//
//  RegistrationClass.h
//  Pods
//
//  Created by Times Internet Limited on 30/08/16.
//
//

#import <Foundation/Foundation.h>

@interface RegistrationClass : NSObject<NSCoding,NSCopying>

@property (nonatomic,strong) NSString *cokeversion;
@property (nonatomic,strong) NSNumber *cokeEnabled;
@property (nonatomic,strong) NSNumber *compressionEnabled;
@property (nonatomic,strong) NSString *cokeUID;
@property (nonatomic,strong) NSDictionary *urlMappings;
@property (nonatomic,strong) NSDictionary *additionalURLMappings;
@property (nonatomic,strong) NSString *clientMsgQueueSize;
@property (nonatomic,strong) NSString *eventsBatchSize;
@property (nonatomic,strong) NSNumber *optedOut;

@end
